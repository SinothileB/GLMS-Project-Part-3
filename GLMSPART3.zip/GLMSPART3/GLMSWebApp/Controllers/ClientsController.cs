﻿using GLMSWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;

namespace GLMSWebApp.Controllers
{
    public class ClientsController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiBaseUrl;

        public ClientsController(
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _httpClient = httpClientFactory.CreateClient();
            _apiBaseUrl = configuration["ApiBaseUrl"] ?? "https://localhost:7135/api";
        }

        public async Task<IActionResult> Index()
        {
            var clients = await _httpClient.GetFromJsonAsync<List<Client>>($"{_apiBaseUrl}/clients");
            return View(clients ?? new List<Client>());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Client client)
        {
            if (ModelState.IsValid)
            {
                var response = await _httpClient.PostAsJsonAsync($"{_apiBaseUrl}/clients", client);

                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));

                ModelState.AddModelError("", "Failed to create client using API.");
            }

            return View(client);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var client = await _httpClient.GetFromJsonAsync<Client>($"{_apiBaseUrl}/clients/{id}");

            if (client == null)
                return NotFound();

            return View(client);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Client client)
        {
            if (id != client.ClientId)
                return NotFound();

            if (ModelState.IsValid)
            {
                var response = await _httpClient.PutAsJsonAsync($"{_apiBaseUrl}/clients/{id}", client);

                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));

                ModelState.AddModelError("", "Failed to update client using API.");
            }

            return View(client);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var client = await _httpClient.GetFromJsonAsync<Client>($"{_apiBaseUrl}/clients/{id}");

            if (client == null)
                return NotFound();

            return View(client);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"{_apiBaseUrl}/clients/{id}");

            if (response.IsSuccessStatusCode)
                return RedirectToAction(nameof(Index));

            var client = await _httpClient.GetFromJsonAsync<Client>($"{_apiBaseUrl}/clients/{id}");
            ModelState.AddModelError("", "Cannot delete this client using API.");

            return View("Delete", client);
        }
    }
}