﻿using GLMSWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net.Http.Json;

namespace GLMSWebApp.Controllers
{
    public class ServiceRequestsController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string _apiBaseUrl;

        public ServiceRequestsController(
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _httpClient = httpClientFactory.CreateClient();

            _apiBaseUrl = configuration["ApiBaseUrl"] ?? "https://localhost:7135/api";
        }
        public async Task<IActionResult> Index()
        {
            var serviceRequests = await _httpClient.GetFromJsonAsync<List<ServiceRequest>>($"{_apiBaseUrl}/service-requests");
            return View(serviceRequests ?? new List<ServiceRequest>());
        }

        public async Task<IActionResult> Create()
        {
            await LoadContractsDropDown();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ServiceRequest serviceRequest)
        {
            var contracts = await _httpClient.GetFromJsonAsync<List<Contract>>($"{_apiBaseUrl}/contracts");
            var contract = contracts?.FirstOrDefault(c => c.ContractId == serviceRequest.ContractId);

            if (contract == null)
                ModelState.AddModelError("", "Selected contract does not exist.");
            else if (contract.Status == "Expired" || contract.Status == "On Hold")
                ModelState.AddModelError("", "A service request cannot be created for an expired or on-hold contract.");

            if (ModelState.IsValid)
            {
                var exchangeRate = await GetUsdToZarRateAsync();
                serviceRequest.CostZar = serviceRequest.CostUsd * exchangeRate;

                var response = await _httpClient.PostAsJsonAsync($"{_apiBaseUrl}/service-requests", serviceRequest);

                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));

                ModelState.AddModelError("", "Failed to create service request using API.");
            }

            await LoadContractsDropDown(serviceRequest.ContractId);
            return View(serviceRequest);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var serviceRequest = await _httpClient.GetFromJsonAsync<ServiceRequest>($"{_apiBaseUrl}/service-requests/{id}");

            if (serviceRequest == null)
                return NotFound();

            await LoadContractsDropDown(serviceRequest.ContractId);
            return View(serviceRequest);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ServiceRequest serviceRequest)
        {
            if (id != serviceRequest.ServiceRequestId)
                return NotFound();

            var contracts = await _httpClient.GetFromJsonAsync<List<Contract>>($"{_apiBaseUrl}/contracts");
            var contract = contracts?.FirstOrDefault(c => c.ContractId == serviceRequest.ContractId);

            if (contract == null)
                ModelState.AddModelError("", "Selected contract does not exist.");
            else if (contract.Status == "Expired" || contract.Status == "On Hold")
                ModelState.AddModelError("", "A service request cannot be linked to an expired or on-hold contract.");

            if (ModelState.IsValid)
            {
                var exchangeRate = await GetUsdToZarRateAsync();
                serviceRequest.CostZar = serviceRequest.CostUsd * exchangeRate;

                var response = await _httpClient.PutAsJsonAsync($"{_apiBaseUrl}/service-requests/{id}", serviceRequest);

                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));

                ModelState.AddModelError("", "Failed to update service request using API.");
            }

            await LoadContractsDropDown(serviceRequest.ContractId);
            return View(serviceRequest);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var serviceRequest = await _httpClient.GetFromJsonAsync<ServiceRequest>($"{_apiBaseUrl}/service-requests/{id}");

            if (serviceRequest == null)
                return NotFound();

            return View(serviceRequest);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"{_apiBaseUrl}/service-requests/{id}");

            if (response.IsSuccessStatusCode)
                return RedirectToAction(nameof(Index));

            var serviceRequest = await _httpClient.GetFromJsonAsync<ServiceRequest>($"{_apiBaseUrl}/service-requests/{id}");
            ModelState.AddModelError("", "Failed to delete service request using API.");

            return View("Delete", serviceRequest);
        }

        private async Task LoadContractsDropDown(int? selectedContractId = null)
        {
            var contracts = await _httpClient.GetFromJsonAsync<List<Contract>>($"{_apiBaseUrl}/contracts");

            ViewBag.ContractId = contracts?
                .Select(c => new SelectListItem
                {
                    Value = c.ContractId.ToString(),
                    Text = (c.Client != null ? c.Client.Name : "Unknown Client") + " - " + c.Status + " - Contract #" + c.ContractId,
                    Selected = selectedContractId.HasValue && c.ContractId == selectedContractId.Value
                }).ToList();
        }

        private async Task<decimal> GetUsdToZarRateAsync()
        {
            try
            {
                var client = _httpClientFactory.CreateClient();

                var response = await client.GetFromJsonAsync<ExchangeRateResponse>(
                    "https://v6.exchangerate-api.com/v6/0cdfe10488c1d15eb6a1c350/latest/USD");

                if (response != null && response.conversion_rates.ContainsKey("ZAR"))
                    return response.conversion_rates["ZAR"];
            }
            catch
            {
            }

            return 16.50m;
        }

        public class ExchangeRateResponse
        {
            public Dictionary<string, decimal> conversion_rates { get; set; } = new();
        }
    }
}