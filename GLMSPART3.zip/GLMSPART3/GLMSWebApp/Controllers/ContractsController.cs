﻿using GLMSWebApp.Models;
using GLMSWebApp.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net.Http.Json;

namespace GLMSWebApp.Controllers
{
    public class ContractsController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiBaseUrl;

        public ContractsController(
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _httpClient = httpClientFactory.CreateClient();
            _apiBaseUrl = configuration["ApiBaseUrl"] ?? "https://localhost:7135/api";
        }

        public async Task<IActionResult> Index(string? searchTerm, string? status, DateTime? startDate, DateTime? endDate)
        {
            var contracts = await _httpClient.GetFromJsonAsync<List<Contract>>($"{_apiBaseUrl}/contracts");

            contracts ??= new List<Contract>();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                contracts = contracts.Where(c =>
                    c.Client != null &&
                    c.Client.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (!string.IsNullOrEmpty(status))
            {
                contracts = contracts.Where(c =>
                    c.Status != null &&
                    c.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (startDate.HasValue)
                contracts = contracts.Where(c => c.StartDate >= startDate.Value).ToList();

            if (endDate.HasValue)
                contracts = contracts.Where(c => c.EndDate <= endDate.Value).ToList();

            ViewBag.SearchTerm = searchTerm;
            ViewBag.Status = status;
            ViewBag.StartDate = startDate?.ToString("yyyy-MM-dd");
            ViewBag.EndDate = endDate?.ToString("yyyy-MM-dd");

            return View(contracts);
        }

        public async Task<IActionResult> Create()
        {
            var clients = await _httpClient.GetFromJsonAsync<List<Client>>($"{_apiBaseUrl}/clients");
            ViewBag.ClientId = new SelectList(clients, "ClientId", "Name");

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Contract contract)
        {
            if (contract.PdfFile != null)
            {
                var extension = Path.GetExtension(contract.PdfFile.FileName).ToLower();

                if (!FileValidationHelper.IsPdfFile(contract.PdfFile.FileName))
                {
                    ModelState.AddModelError("PdfFile", "Only PDF files are allowed.");
                }
                else
                {
                    var fileName = Guid.NewGuid().ToString() + extension;
                    var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles");

                    if (!Directory.Exists(uploadPath))
                        Directory.CreateDirectory(uploadPath);

                    var filePath = Path.Combine(uploadPath, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await contract.PdfFile.CopyToAsync(stream);
                    }

                    contract.PdfFilePath = fileName;
                }
            }

            if (ModelState.IsValid)
            {
                contract.PdfFile = null;

                var response = await _httpClient.PostAsJsonAsync($"{_apiBaseUrl}/contracts", contract);

                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));

                ModelState.AddModelError("", "Failed to create contract using API.");
            }

            var clients = await _httpClient.GetFromJsonAsync<List<Client>>($"{_apiBaseUrl}/clients");
            ViewBag.ClientId = new SelectList(clients, "ClientId", "Name", contract.ClientId);

            return View(contract);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var contract = await _httpClient.GetFromJsonAsync<Contract>($"{_apiBaseUrl}/contracts/{id}");

            if (contract == null)
                return NotFound();

            var clients = await _httpClient.GetFromJsonAsync<List<Client>>($"{_apiBaseUrl}/clients");
            ViewBag.ClientId = new SelectList(clients, "ClientId", "Name", contract.ClientId);

            return View(contract);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Contract contract)
        {
            if (id != contract.ContractId)
                return NotFound();

            if (ModelState.IsValid)
            {
                contract.PdfFile = null;

                var response = await _httpClient.PutAsJsonAsync($"{_apiBaseUrl}/contracts/{id}", contract);

                if (response.IsSuccessStatusCode)
                    return RedirectToAction(nameof(Index));

                ModelState.AddModelError("", "Failed to update contract using API.");
            }

            var clients = await _httpClient.GetFromJsonAsync<List<Client>>($"{_apiBaseUrl}/clients");
            ViewBag.ClientId = new SelectList(clients, "ClientId", "Name", contract.ClientId);

            return View(contract);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var contract = await _httpClient.GetFromJsonAsync<Contract>($"{_apiBaseUrl}/contracts/{id}");

            if (contract == null)
                return NotFound();

            return View(contract);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"{_apiBaseUrl}/contracts/{id}");

            if (response.IsSuccessStatusCode)
                return RedirectToAction(nameof(Index));

            var contract = await _httpClient.GetFromJsonAsync<Contract>($"{_apiBaseUrl}/contracts/{id}");
            ModelState.AddModelError("", "Cannot delete this contract using API.");

            return View("Delete", contract);
        }

        public IActionResult DownloadPdf(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
                return NotFound();

            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "UploadedFiles", fileName);

            if (!System.IO.File.Exists(filePath))
                return NotFound();

            var fileBytes = System.IO.File.ReadAllBytes(filePath);

            return File(fileBytes, "application/pdf", fileName);
        }
    }
}