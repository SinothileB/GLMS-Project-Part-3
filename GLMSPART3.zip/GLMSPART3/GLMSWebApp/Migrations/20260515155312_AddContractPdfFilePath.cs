﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GLMSWebApp.Migrations
{
    /// <inheritdoc />
    public partial class AddContractPdfFilePath : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PdfFilePath",
                table: "ServiceRequests");

            migrationBuilder.AddColumn<string>(
                name: "PdfFilePath",
                table: "Contracts",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PdfFilePath",
                table: "Contracts");

            migrationBuilder.AddColumn<string>(
                name: "PdfFilePath",
                table: "ServiceRequests",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
