﻿using GLMSWebApp.Models;

namespace GLMSWebApp.Repositories
{
    public interface IContractRepository
    {
        Task<IEnumerable<Contract>> GetAllAsync();

        Task<Contract?> GetByIdAsync(int id);

        Task AddAsync(Contract contract);

        Task UpdateAsync(Contract contract);

        Task DeleteAsync(int id);

        Task<IEnumerable<Contract>> SearchAsync(string? searchTerm, string? status, DateTime? startDate, DateTime? endDate);
    }
}