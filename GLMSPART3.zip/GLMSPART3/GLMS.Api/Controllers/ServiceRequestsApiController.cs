﻿using GLMS.Api.Models;
using GLMS.Api.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Api.Controllers
{
    [Route("api/service-requests")]
    [ApiController]
    public class ServiceRequestsApiController : ControllerBase
    {
        private readonly IServiceRequestRepository _serviceRequestRepository;

        public ServiceRequestsApiController(IServiceRequestRepository serviceRequestRepository)
        {
            _serviceRequestRepository = serviceRequestRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetServiceRequests()
        {
            var serviceRequests = await _serviceRequestRepository.GetAllAsync();
            return Ok(serviceRequests);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetServiceRequest(int id)
        {
            var serviceRequest = await _serviceRequestRepository.GetByIdAsync(id);

            if (serviceRequest == null)
                return NotFound();

            return Ok(serviceRequest);
        }

        [HttpPost]
        public async Task<IActionResult> CreateServiceRequest([FromBody] ServiceRequest serviceRequest)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _serviceRequestRepository.AddAsync(serviceRequest);

            return CreatedAtAction(nameof(GetServiceRequest), new { id = serviceRequest.ServiceRequestId }, serviceRequest);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateServiceRequest(int id, [FromBody] ServiceRequest serviceRequest)
        {
            if (id != serviceRequest.ServiceRequestId)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _serviceRequestRepository.UpdateAsync(serviceRequest);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteServiceRequest(int id)
        {
            var serviceRequest = await _serviceRequestRepository.GetByIdAsync(id);

            if (serviceRequest == null)
                return NotFound();

            await _serviceRequestRepository.DeleteAsync(id);

            return NoContent();
        }
    }
}