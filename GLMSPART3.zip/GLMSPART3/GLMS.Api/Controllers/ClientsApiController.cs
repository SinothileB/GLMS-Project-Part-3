﻿using GLMS.Api.Models;
using GLMS.Api.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Api.Controllers
{
    [Route("api/clients")]
    [ApiController]
    public class ClientsApiController : ControllerBase
    {
        private readonly IClientRepository _clientRepository;

        public ClientsApiController(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetClients()
        {
            var clients = await _clientRepository.GetAllAsync();
            return Ok(clients);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetClient(int id)
        {
            var client = await _clientRepository.GetByIdAsync(id);

            if (client == null)
                return NotFound();

            return Ok(client);
        }

        [HttpPost]
        public async Task<IActionResult> CreateClient([FromBody] Client client)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _clientRepository.AddAsync(client);

            return CreatedAtAction(nameof(GetClient), new { id = client.ClientId }, client);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateClient(int id, [FromBody] Client client)
        {
            if (id != client.ClientId)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _clientRepository.UpdateAsync(client);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteClient(int id)
        {
            var client = await _clientRepository.GetByIdAsync(id);

            if (client == null)
                return NotFound();

            await _clientRepository.DeleteAsync(id);

            return NoContent();
        }
    }
}