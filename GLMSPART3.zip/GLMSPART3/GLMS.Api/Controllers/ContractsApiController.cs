﻿using GLMS.Api.Models;
using GLMS.Api.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Api.Controllers
{
    [Route("api/contracts")]
    [ApiController]
    public class ContractsApiController : ControllerBase
    {
        private readonly IContractRepository _contractRepository;

        public ContractsApiController(IContractRepository contractRepository)
        {
            _contractRepository = contractRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetContracts()
        {
            var contracts = await _contractRepository.GetAllAsync();
            return Ok(contracts);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetContract(int id)
        {
            var contract = await _contractRepository.GetByIdAsync(id);

            if (contract == null)
                return NotFound();

            return Ok(contract);
        }

        [HttpPost]
        public async Task<IActionResult> CreateContract([FromBody] Contract contract)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _contractRepository.AddAsync(contract);

            return CreatedAtAction(nameof(GetContract), new { id = contract.ContractId }, contract);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateContract(int id, [FromBody] Contract contract)
        {
            if (id != contract.ContractId)
                return BadRequest();

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _contractRepository.UpdateAsync(contract);

            return NoContent();
        }

        [HttpPatch("{id}/status")]
        public async Task<IActionResult> UpdateContractStatus(int id, [FromBody] string status)
        {
            var contract = await _contractRepository.GetByIdAsync(id);

            if (contract == null)
                return NotFound();

            contract.Status = status;

            await _contractRepository.UpdateAsync(contract);

            return Ok(contract);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteContract(int id)
        {
            var contract = await _contractRepository.GetByIdAsync(id);

            if (contract == null)
                return NotFound();

            await _contractRepository.DeleteAsync(id);

            return NoContent();
        }
    }
}