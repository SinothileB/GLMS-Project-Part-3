﻿using System.ComponentModel.DataAnnotations;


namespace GLMS.Api.Models
{
    public class ServiceRequest
    {
        public int ServiceRequestId { get; set; }

        [Required]
        public int ContractId { get; set; }

        public Contract? Contract { get; set; }

        [Required]
        [StringLength(250)]
        public string Description { get; set; } = string.Empty;

        [Required]
        [Range(0.01, 1000000)]
        public decimal CostUsd { get; set; }

        public decimal CostZar { get; set; }

        [StringLength(20)]
        public string Status { get; set; } = "Pending";

       
    }
}