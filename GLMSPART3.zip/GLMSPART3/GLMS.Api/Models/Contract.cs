﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations.Schema;
namespace GLMS.Api.Models
{
    public class Contract
    {
        public int ContractId { get; set; }

        [Required]
        public int ClientId { get; set; }

        public Client? Client { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Draft";

        [Required]
        [StringLength(50)]
        public string ServiceLevel { get; set; } = string.Empty;

        public string? PdfFilePath { get; set; }

        [NotMapped]
        [Display(Name = "Upload PDF Contract")]
        public IFormFile? PdfFile { get; set; }

        public ICollection<ServiceRequest> ServiceRequests { get; set; } = new List<ServiceRequest>();
    }
}