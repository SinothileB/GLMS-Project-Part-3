﻿using GLMS.Api.Data;
using GLMS.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace  GLMS.Api.Repositories
{
    public class ContractRepository : IContractRepository
    {
        private readonly ApplicationDbContext _context;

        public ContractRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Contract>> GetAllAsync()
        {
            return await _context.Contracts
                .Include(c => c.Client)
                .ToListAsync();
        }

        public async Task<Contract?> GetByIdAsync(int id)
        {
            return await _context.Contracts
                .Include(c => c.Client)
                .FirstOrDefaultAsync(c => c.ContractId == id);
        }

        public async Task AddAsync(Contract contract)
        {
            _context.Contracts.Add(contract);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Contract contract)
        {
            _context.Contracts.Update(contract);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var contract = await _context.Contracts
                .Include(c => c.ServiceRequests)
                .FirstOrDefaultAsync(c => c.ContractId == id);

            if (contract != null)
            {
                if (contract.ServiceRequests.Any())
                {
                    throw new InvalidOperationException(
                        "This contract cannot be deleted because it has service requests linked to it.");
                }

                _context.Contracts.Remove(contract);
                await _context.SaveChangesAsync();
            }
        }
        public async Task<IEnumerable<Contract>> SearchAsync(
            string? searchTerm,
            string? status,
            DateTime? startDate,
            DateTime? endDate)
        {
            var query = _context.Contracts
                .Include(c => c.Client)
                .AsQueryable();

            // Search by client name
            if (!string.IsNullOrEmpty(searchTerm))
            {
                query = query.Where(c =>
                    c.Client.Name.Contains(searchTerm));
            }

            // Filter by status
            if (!string.IsNullOrEmpty(status))
            {
                query = query.Where(c =>
                    c.Status == status);
            }

            // Filter by start date
            if (startDate.HasValue)
            {
                query = query.Where(c =>
                    c.StartDate >= startDate.Value);
            }

            // Filter by end date
            if (endDate.HasValue)
            {
                query = query.Where(c =>
                    c.EndDate <= endDate.Value);
            }

            return await query.ToListAsync();
        }
    }
}