﻿using GLMS.Api.Models;
namespace 
    GLMS.Api.Repositories

{
    public interface IServiceRequestRepository
    {
        Task<IEnumerable<ServiceRequest>> GetAllAsync();

        Task<ServiceRequest?> GetByIdAsync(int id);

        Task AddAsync(ServiceRequest serviceRequest);

        Task UpdateAsync(ServiceRequest serviceRequest);

        Task DeleteAsync(int id);
    }
}