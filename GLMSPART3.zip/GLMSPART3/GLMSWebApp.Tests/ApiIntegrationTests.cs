﻿using GLMSWebApp.Models;
using System.Net;
using System.Net.Http.Json;

namespace GLMSWebApp.Tests
{
    public class ApiIntegrationTests
    {
        private readonly HttpClient _client = new HttpClient
        {
            BaseAddress = new Uri("http://localhost:7135")
        };

        [Fact]
        public async Task GetContracts_ReturnsSuccessStatusCode()
        {
            var response = await _client.GetAsync("/api/contracts");
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task GetClients_ReturnsSuccessStatusCode()
        {
            var response = await _client.GetAsync("/api/clients");
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task GetServiceRequests_ReturnsSuccessStatusCode()
        {
            var response = await _client.GetAsync("/api/service-requests");
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task Client_CRUD_WorksSuccessfully()
        {
            var newClient = new
            {
                name = "Integration Test Client",
                contactDetails = "0712345678",
                region = "Gauteng"
            };

            var postResponse = await _client.PostAsJsonAsync("/api/clients", newClient);
            Assert.Equal(HttpStatusCode.Created, postResponse.StatusCode);

            var createdClient = await postResponse.Content.ReadFromJsonAsync<Client>();
            Assert.NotNull(createdClient);
            Assert.True(createdClient.ClientId > 0);

            var getResponse = await _client.GetAsync($"/api/clients/{createdClient.ClientId}");
            Assert.Equal(HttpStatusCode.OK, getResponse.StatusCode);

            var updatedClient = new
            {
                clientId = createdClient.ClientId,
                name = "Updated Integration Test Client",
                contactDetails = "0799999999",
                region = "Western Cape"
            };

            var putResponse = await _client.PutAsJsonAsync($"/api/clients/{createdClient.ClientId}", updatedClient);
            Assert.Equal(HttpStatusCode.NoContent, putResponse.StatusCode);

            var deleteResponse = await _client.DeleteAsync($"/api/clients/{createdClient.ClientId}");
            Assert.Equal(HttpStatusCode.NoContent, deleteResponse.StatusCode);
        }

        [Fact]
        public async Task Contract_CRUD_WorksSuccessfully()
        {
            var testClient = new
            {
                name = "Contract Test Client",
                contactDetails = "0722222222",
                region = "KwaZulu-Natal"
            };

            var clientResponse = await _client.PostAsJsonAsync("/api/clients", testClient);
            Assert.Equal(HttpStatusCode.Created, clientResponse.StatusCode);

            var createdClient = await clientResponse.Content.ReadFromJsonAsync<Client>();
            Assert.NotNull(createdClient);

            var newContract = new
            {
                clientId = createdClient.ClientId,
                startDate = DateTime.Now,
                endDate = DateTime.Now.AddMonths(6),
                status = "Active",
                serviceLevel = "Standard",
                pdfFilePath = "integration-test.pdf"
            };

            var postResponse = await _client.PostAsJsonAsync("/api/contracts", newContract);
            Assert.Equal(HttpStatusCode.Created, postResponse.StatusCode);

            var createdContract = await postResponse.Content.ReadFromJsonAsync<Contract>();
            Assert.NotNull(createdContract);
            Assert.True(createdContract.ContractId > 0);

            var getResponse = await _client.GetAsync($"/api/contracts/{createdContract.ContractId}");
            Assert.Equal(HttpStatusCode.OK, getResponse.StatusCode);

            var updatedContract = new
            {
                contractId = createdContract.ContractId,
                clientId = createdClient.ClientId,
                startDate = DateTime.Now,
                endDate = DateTime.Now.AddMonths(12),
                status = "Active",
                serviceLevel = "Premium",
                pdfFilePath = "updated-integration-test.pdf"
            };

            var putResponse = await _client.PutAsJsonAsync($"/api/contracts/{createdContract.ContractId}", updatedContract);
            Assert.Equal(HttpStatusCode.NoContent, putResponse.StatusCode);

            var deleteContractResponse = await _client.DeleteAsync($"/api/contracts/{createdContract.ContractId}");
            Assert.Equal(HttpStatusCode.NoContent, deleteContractResponse.StatusCode);

            var deleteClientResponse = await _client.DeleteAsync($"/api/clients/{createdClient.ClientId}");
            Assert.Equal(HttpStatusCode.NoContent, deleteClientResponse.StatusCode);
        }

        [Fact]
        public async Task ServiceRequest_CRUD_WorksSuccessfully()
        {
            var testClient = new
            {
                name = "Service Request Test Client",
                contactDetails = "0733333333",
                region = "Eastern Cape"
            };

            var clientResponse = await _client.PostAsJsonAsync("/api/clients", testClient);
            Assert.Equal(HttpStatusCode.Created, clientResponse.StatusCode);

            var createdClient = await clientResponse.Content.ReadFromJsonAsync<Client>();
            Assert.NotNull(createdClient);

            var testContract = new
            {
                clientId = createdClient.ClientId,
                startDate = DateTime.Now,
                endDate = DateTime.Now.AddMonths(6),
                status = "Active",
                serviceLevel = "Standard",
                pdfFilePath = "service-request-test.pdf"
            };

            var contractResponse = await _client.PostAsJsonAsync("/api/contracts", testContract);
            Assert.Equal(HttpStatusCode.Created, contractResponse.StatusCode);

            var createdContract = await contractResponse.Content.ReadFromJsonAsync<Contract>();
            Assert.NotNull(createdContract);

            var newRequest = new
            {
                contractId = createdContract.ContractId,
                description = "Integration Test Request",
                costUsd = 1000,
                costZar = 18500,
                status = "Pending"
            };

            var postResponse = await _client.PostAsJsonAsync("/api/service-requests", newRequest);
            Assert.Equal(HttpStatusCode.Created, postResponse.StatusCode);

            var createdRequest = await postResponse.Content.ReadFromJsonAsync<ServiceRequest>();
            Assert.NotNull(createdRequest);
            Assert.True(createdRequest.ServiceRequestId > 0);

            var getResponse = await _client.GetAsync($"/api/service-requests/{createdRequest.ServiceRequestId}");
            Assert.Equal(HttpStatusCode.OK, getResponse.StatusCode);

            var updatedRequest = new
            {
                serviceRequestId = createdRequest.ServiceRequestId,
                contractId = createdContract.ContractId,
                description = "Updated Integration Test Request",
                costUsd = 1200,
                costZar = 22200,
                status = "Completed"
            };

            var putResponse = await _client.PutAsJsonAsync(
                $"/api/service-requests/{createdRequest.ServiceRequestId}",
                updatedRequest);

            Assert.Equal(HttpStatusCode.NoContent, putResponse.StatusCode);

            var deleteRequestResponse = await _client.DeleteAsync($"/api/service-requests/{createdRequest.ServiceRequestId}");
            Assert.Equal(HttpStatusCode.NoContent, deleteRequestResponse.StatusCode);

            var deleteContractResponse = await _client.DeleteAsync($"/api/contracts/{createdContract.ContractId}");
            Assert.Equal(HttpStatusCode.NoContent, deleteContractResponse.StatusCode);

            var deleteClientResponse = await _client.DeleteAsync($"/api/clients/{createdClient.ClientId}");
            Assert.Equal(HttpStatusCode.NoContent, deleteClientResponse.StatusCode);
        }
    }
}