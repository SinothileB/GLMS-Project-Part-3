﻿using GLMSWebApp.Data;
using GLMSWebApp.Models;
using GLMSWebApp.Repositories;
using Microsoft.EntityFrameworkCore;

namespace GLMSWebApp.Tests.Repositories
{
    public class ServiceRequestRepositoryTests
    {
        private ApplicationDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new ApplicationDbContext(options);
        }

        [Fact]
        public async Task AddAsync_ShouldAddServiceRequest()
        {
            var context = GetDbContext();
            var repository = new ServiceRequestRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Test Client",
                ContactDetails = "test@email.com",
                Region = "South Africa"
            });

            context.Contracts.Add(new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Premium",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            });

            await context.SaveChangesAsync();

            var serviceRequest = new ServiceRequest
            {
                ContractId = 1,
                Description = "Deliver goods",
                CostUsd = 50,
                CostZar = 825,
                Status = "Pending"
            };

            await repository.AddAsync(serviceRequest);

            Assert.Single(context.ServiceRequests);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnServiceRequest()
        {
            var context = GetDbContext();
            var repository = new ServiceRequestRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "TechMove",
                ContactDetails = "info@techmove.com",
                Region = "Gauteng"
            });

            context.Contracts.Add(new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Premium",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            });

            context.ServiceRequests.Add(new ServiceRequest
            {
                ServiceRequestId = 1,
                ContractId = 1,
                Description = "Warehouse delivery",
                CostUsd = 20,
                CostZar = 330,
                Status = "Pending"
            });

            await context.SaveChangesAsync();

            var result = await repository.GetByIdAsync(1);

            Assert.NotNull(result);
            Assert.Equal("Warehouse delivery", result!.Description);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateServiceRequest()
        {
            var context = GetDbContext();
            var repository = new ServiceRequestRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Update Client",
                ContactDetails = "update@email.com",
                Region = "KZN"
            });

            context.Contracts.Add(new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Standard",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            });

            var serviceRequest = new ServiceRequest
            {
                ServiceRequestId = 1,
                ContractId = 1,
                Description = "Old request",
                CostUsd = 30,
                CostZar = 495,
                Status = "Pending"
            };

            context.ServiceRequests.Add(serviceRequest);
            await context.SaveChangesAsync();

            serviceRequest.Status = "Approved";

            await repository.UpdateAsync(serviceRequest);

            var updatedRequest = await context.ServiceRequests.FindAsync(1);

            Assert.Equal("Approved", updatedRequest!.Status);
        }

        [Fact]
        public async Task DeleteAsync_ShouldDeleteServiceRequest()
        {
            var context = GetDbContext();
            var repository = new ServiceRequestRepository(context);

            context.ServiceRequests.Add(new ServiceRequest
            {
                ServiceRequestId = 1,
                ContractId = 1,
                Description = "Delete request",
                CostUsd = 10,
                CostZar = 165,
                Status = "Pending"
            });

            await context.SaveChangesAsync();

            await repository.DeleteAsync(1);

            Assert.Empty(context.ServiceRequests);
        }

      
        [Fact]
        public void CurrencyCalculation_ShouldConvertUsdToZarCorrectly()
        {
            // Arrange
            var serviceRequest = new ServiceRequest
            {
                CostUsd = 100m
            };

            decimal exchangeRate = 18.50m;

            // Act
            serviceRequest.CostZar = serviceRequest.CostUsd * exchangeRate;

            // Assert
            Assert.Equal(1850.00m, serviceRequest.CostZar);
        }

        [Theory]
        [InlineData("Expired")]
        [InlineData("On Hold")]
        public void WorkflowValidation_ShouldRejectInvalidContractStatus(string contractStatus)
        {
            bool canCreateServiceRequest =
                contractStatus != "Expired" && contractStatus != "On Hold";

            Assert.False(canCreateServiceRequest);
        }

        [Fact]
        public void WorkflowValidation_ShouldAllowActiveContract()
        {
            string contractStatus = "Active";

            bool canCreateServiceRequest =
                contractStatus != "Expired" && contractStatus != "On Hold";

            Assert.True(canCreateServiceRequest);
        }
    }
}