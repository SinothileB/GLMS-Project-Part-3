﻿using GLMSWebApp.Data;
using GLMSWebApp.Models;
using GLMSWebApp.Repositories;
using Microsoft.EntityFrameworkCore;

namespace GLMSWebApp.Tests.Repositories
{
    public class ContractRepositoryTests
    {
        private ApplicationDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new ApplicationDbContext(options);
        }

        [Fact]
        public async Task AddAsync_ShouldAddContract()
        {
            var context = GetDbContext();
            var repository = new ContractRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Test Client",
                ContactDetails = "test@email.com",
                Region = "South Africa"
            });

            await context.SaveChangesAsync();

            var contract = new Contract
            {
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Premium",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            };

            await repository.AddAsync(contract);

            Assert.Single(context.Contracts);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnContract()
        {
            var context = GetDbContext();
            var repository = new ContractRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "TechMove",
                ContactDetails = "info@techmove.com",
                Region = "Gauteng"
            });

            context.Contracts.Add(new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Premium",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            });

            await context.SaveChangesAsync();

            var result = await repository.GetByIdAsync(1);

            Assert.NotNull(result);
            Assert.Equal("Premium", result!.ServiceLevel);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateContract()
        {
            var context = GetDbContext();
            var repository = new ContractRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Update Client",
                ContactDetails = "update@email.com",
                Region = "KZN"
            });

            var contract = new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Draft",
                ServiceLevel = "Basic",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            };

            context.Contracts.Add(contract);
            await context.SaveChangesAsync();

            contract.Status = "Active";

            await repository.UpdateAsync(contract);

            var updatedContract = await context.Contracts.FindAsync(1);

            Assert.Equal("Active", updatedContract!.Status);
        }

        [Fact]
        public async Task SearchAsync_ShouldFilterContractsByStatus()
        {
            var context = GetDbContext();
            var repository = new ContractRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Sinothile",
                ContactDetails = "test@email.com",
                Region = "South Africa"
            });

            context.Contracts.AddRange(
                new Contract
                {
                    ClientId = 1,
                    Status = "Active",
                    ServiceLevel = "Premium",
                    StartDate = DateTime.Today,
                    EndDate = DateTime.Today.AddMonths(1)
                },
                new Contract
                {
                    ClientId = 1,
                    Status = "Expired",
                    ServiceLevel = "Basic",
                    StartDate = DateTime.Today,
                    EndDate = DateTime.Today.AddMonths(1)
                }
            );

            await context.SaveChangesAsync();

            var result = await repository.SearchAsync(
                null,
                "Active",
                null,
                null);

            Assert.Single(result);
            Assert.Equal("Active", result.First().Status);
        }

        [Fact]
        public async Task DeleteAsync_ShouldDeleteContract_WhenNoServiceRequestsExist()
        {
            var context = GetDbContext();
            var repository = new ContractRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Delete Client",
                ContactDetails = "delete@email.com",
                Region = "Limpopo"
            });

            context.Contracts.Add(new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Premium",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            });

            await context.SaveChangesAsync();

            await repository.DeleteAsync(1);

            Assert.Empty(context.Contracts);
        }

        [Fact]
        public async Task DeleteAsync_ShouldThrowError_WhenContractHasServiceRequests()
        {
            var context = GetDbContext();
            var repository = new ContractRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Test Client",
                ContactDetails = "test@email.com",
                Region = "Western Cape"
            });

            context.Contracts.Add(new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Premium",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            });

            context.ServiceRequests.Add(new ServiceRequest
            {
                ServiceRequestId = 1,
                ContractId = 1,
                Description = "Delivery Request",
                CostUsd = 50,
                CostZar = 900,
                Status = "Pending"
            });

            await context.SaveChangesAsync();

            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                repository.DeleteAsync(1));
        }
    }
}