﻿using GLMSWebApp.Data;
using GLMSWebApp.Models;
using GLMSWebApp.Repositories;
using Microsoft.EntityFrameworkCore;

namespace GLMSWebApp.Tests.Repositories
{
    public class ClientRepositoryTests
    {
        private ApplicationDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new ApplicationDbContext(options);
        }

        [Fact]
        public async Task AddAsync_ShouldAddClient()
        {
            var context = GetDbContext();
            var repository = new ClientRepository(context);

            var client = new Client
            {
                Name = "Test Client",
                ContactDetails = "test@email.com",
                Region = "South Africa"
            };

            await repository.AddAsync(client);

            Assert.Single(context.Clients);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnClient()
        {
            var context = GetDbContext();
            var repository = new ClientRepository(context);

            var client = new Client
            {
                ClientId = 1,
                Name = "TechMove",
                ContactDetails = "info@techmove.com",
                Region = "Gauteng"
            };

            context.Clients.Add(client);
            await context.SaveChangesAsync();

            var result = await repository.GetByIdAsync(1);

            Assert.NotNull(result);
            Assert.Equal("TechMove", result!.Name);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateClient()
        {
            var context = GetDbContext();
            var repository = new ClientRepository(context);

            var client = new Client
            {
                ClientId = 1,
                Name = "Old Name",
                ContactDetails = "old@email.com",
                Region = "Gauteng"
            };

            context.Clients.Add(client);
            await context.SaveChangesAsync();

            client.Name = "Updated Name";

            await repository.UpdateAsync(client);

            var updatedClient = await context.Clients.FindAsync(1);

            Assert.Equal("Updated Name", updatedClient!.Name);
        }

        [Fact]
        public async Task DeleteAsync_ShouldDeleteClient_WhenNoContractsExist()
        {
            var context = GetDbContext();
            var repository = new ClientRepository(context);

            var client = new Client
            {
                ClientId = 1,
                Name = "Delete Client",
                ContactDetails = "delete@email.com",
                Region = "KZN"
            };

            context.Clients.Add(client);
            await context.SaveChangesAsync();

            await repository.DeleteAsync(1);

            Assert.Empty(context.Clients);
        }

        [Fact]
        public async Task DeleteAsync_ShouldThrowError_WhenClientHasContracts()
        {
            var context = GetDbContext();
            var repository = new ClientRepository(context);

            context.Clients.Add(new Client
            {
                ClientId = 1,
                Name = "Linked Client",
                ContactDetails = "linked@email.com",
                Region = "Western Cape"
            });

            context.Contracts.Add(new Contract
            {
                ContractId = 1,
                ClientId = 1,
                Status = "Active",
                ServiceLevel = "Premium",
                StartDate = DateTime.Today,
                EndDate = DateTime.Today.AddMonths(1)
            });

            await context.SaveChangesAsync();

            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                repository.DeleteAsync(1));
        }
    }
}